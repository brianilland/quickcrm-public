export default function Page() {
  return <div>My Accounts Page (Coming soon)</div>;
}