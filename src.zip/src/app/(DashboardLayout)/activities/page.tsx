export default function Page() {
  return <div>My Activities Page (Coming soon)</div>;
}