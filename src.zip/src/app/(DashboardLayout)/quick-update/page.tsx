export default function Page() {
  return <div>Quick Update Page (Coming soon)</div>;
}